#!/bin/bash

source /etc/smarthome/server.conf

OTA_DIR="/var/cache/smarthome/ota"
VERSION_FILE="$OTA_DIR/version.txt"
TMP_VERSION_FILE="$OTA_DIR/version.tmp.txt"
URL="https://raw.githubusercontent.com/OSLUMI/L0JHjnNcFjKowWts/master/jetson"

date +"%Y.%m.%d_%H.%M.%S"

cleanup() {
  echo "Removing /tmp/relay-updating"
  rm -f /tmp/relay-updating
}

trap cleanup EXIT

if [ -f /tmp/relay-updating ]; then
  exit;
fi

touch /tmp/relay-updating
mkdir -p $OTA_DIR

echo "Checking version"
wget -q "$URL/$SERVER/version.txt" -O $TMP_VERSION_FILE
VERSION=$(cat $TMP_VERSION_FILE)
CURRENT_VERSION=""

if [ -f "$VERSION_FILE" ]; then
  CURRENT_VERSION=$(cat $VERSION_FILE)
fi

if [ "$VERSION" != "$CURRENT_VERSION" ]; then
  echo "New version: $VERSION --> download"
  pushd $OTA_DIR
  wget -q "$URL/$SERVER/firmware.tar.gz"
  tar -xvzf firmware.tar.gz
  rm -f firmware.tar.gz
  sh update/script_update.sh
  rm -rf update
  systemctl restart process-manager
  popd
  echo "$VERSION" > $VERSION_FILE
fi

rm -f $TMP_VERSION_FILE