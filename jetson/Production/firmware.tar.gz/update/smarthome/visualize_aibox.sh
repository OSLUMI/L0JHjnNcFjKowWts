#!/bin/bash

ENV_FILE="/var/cache/smarthome/aibox/aibox.conf"

systemctl stop aibox.service
xauth add $(xauth -f /home/nano/.Xauthority list | tail -1)
env $(cat $ENV_FILE | xargs) VISUALIZE=true aibox -c /etc/smarthome/hc-config.json