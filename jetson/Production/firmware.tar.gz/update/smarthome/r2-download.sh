#!/bin/bash

# Check if the correct number of arguments are provided
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <object-key> <output-file-path>"
    exit 1
fi

# Assign input arguments to variables
OBJECT_KEY=$1
OUTPUT_FILE_PATH=$2

# Define your R2 bucket name and endpoint URL
R2_BUCKET_NAME="lm-life-firmware"
R2_ENDPOINT_URL="https://76e8aacb9ac1ce1881749efb0514b32d.r2.cloudflarestorage.com"

# Set AWS credentials as environment variables
export AWS_ACCESS_KEY_ID="cace0738618b7cfa254265f2d6412f16"
export AWS_SECRET_ACCESS_KEY="c8fffcf9e825b29c6df5e84ccb16e6490e8bb0e77dace872d3613b4e063b463c"

# Download the file from Cloudflare R2 using AWS CLI
aws s3 cp "s3://$R2_BUCKET_NAME/$OBJECT_KEY" "$OUTPUT_FILE_PATH" --endpoint-url="$R2_ENDPOINT_URL"

# Check if the download was successful
# shellcheck disable=SC2181
if [ $? -eq 0 ]; then
    echo "File successfully downloaded from R2 with object key: $OBJECT_KEY to $OUTPUT_FILE_PATH"
else
    echo "Failed to download the file from R2"
fi

# Unset the AWS credentials to prevent them from being used by other commands
unset AWS_ACCESS_KEY_ID
unset AWS_SECRET_ACCESS_KEY
