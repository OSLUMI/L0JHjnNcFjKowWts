#!/bin/bash

SERVICE_CHECKING="$1"
SOFTWARE_FILE="/etc/smarthome/app/$SERVICE_CHECKING"
OTA_PENDING_DIR="/etc/smarthome/ota-pending"
OTA_PENDING_STATUS="$OTA_PENDING_DIR/status"
OTA_PENDING_LOG="$OTA_PENDING_DIR/script_update.log"

PENDING_STATUS="$(cat "$OTA_PENDING_STATUS")"

# Remove OTA Pending log if it's larger than 500KB
if [ -e "$OTA_PENDING_LOG" ] && [ $(stat -c%s "$OTA_PENDING_LOG") -gt $((512*1024)) ]; then
  rm -rf "$OTA_PENDING_LOG" || echo "[EROR][$(date)][$0]: Failed to remove OTA Pending log" >> "$OTA_PENDING_LOG"
fi

# Check for new update before start service
if [ -e "$SOFTWARE_FILE" ] && [ "$PENDING_STATUS" -eq 1 ] && [ -s "$SOFTWARE_FILE" ]; then
  echo "[INFO][$(date)][$0][$SERVICE_CHECKING]: NEW FIRMWARE FOUND --> UPDATING BEFORE STARTING" >> "$OTA_PENDING_LOG"
  cp "$SOFTWARE_FILE" "/usr/bin/" && chmod +x "/usr/bin/$SERVICE_CHECKING" && echo "[INFO][$(date)][$0][$SERVICE_CHECKING]: UPDATE DONE" >> "$OTA_PENDING_LOG"
else
  echo "[INFO][$(date)][$0][$SERVICE_CHECKING]: NO UPDATE " >> "$OTA_PENDING_LOG"
fi
